#/bin/bash
logDir="/var/log/thedupe/"
installDir="/etc/thedupe/"
svcDir="/etc/systemd/system/"
version="0.2.4"

if [ `whoami` != root ];
then
        echo Please run this script as root or using sudo
        exit
fi

echo Uninstalling The Dupe "$version" from your computer.

systemctl stop thedupe.service
systemctl disable thedupe.service
rm -rf "$installDir"
rm -rf "$logDir"
rm "$svcDir"thedupe.service

echo Uninstallation done.
