#/bin/bash
logDir="/var/log/thedupe/"
installDir="/etc/thedupe/"
propDir="$installDir""Properties/"
svcDir="/etc/systemd/system/"
version="0.2.6"
minDotNetVer="5.0.5"

if [ `whoami` != root ];
then
	echo Please run this script as root or using sudo
        exit
fi

read -p "This will install The Dupe $version in this computer. Continue (Y)es or (N)o?: " input

if [ "$input" = "y" ] || [ "$input" = "Y" ]; 
then
	echo Installing The Dupe "$version" on your system
	if [ ! -d "$logDir" ];
	then
                mkdir "$logDir"
        fi

	if [ ! -d "$installDir" ];
	then
		mkdir "$installDir"
		mkdir "$propDir"
	fi

        cp -f readme.md "$installDir"
	cp -f TheDupe "$installDir"
	cp -f TheDupe.pdb "$installDir"
	cp -f UNINSTALL.sh "$installDir"
	cp -rf Properties/ "$propDir"
        cp thedupe.service "$svcDir"
        chmod +x "$installDir"TheDupe
	chmod +x "$installDir"UNINSTALL.sh
	systemctl enable thedupe.service
	systemctl start thedupe.service

	echo Installation done. Please go to the installation directory and modify the following values in dupe.conf
	tput setaf 3 
	echo REMINDER: THIS PROGRAM REQUIRES AT LEAST .NET CORE 5.0.5 TO RUN PROPERLY.
	echo See link for more details. https://docs.microsoft.com/en-us/dotnet/core/install/linux
	tput sgr0
	echo interface_id=ABCDEF12-3456-7890-ABCD-EF123456789
	echo ip_address=192.168.69.69
	echo Visit our github repository\'s wiki for more info
	echo https://github.com/BV5Tl0N/TheDupe/wiki
	exit
else
	echo Installation was cancellled. 
	exit
fi
